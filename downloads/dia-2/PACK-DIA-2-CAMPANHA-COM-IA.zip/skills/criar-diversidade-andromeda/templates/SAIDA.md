# Matriz de Diversidade Criativa
| Conceito | Porta de entrada | Gancho | Mensagem | Cena | Formato | CTA | Prova |
|---|---|---|---|---|---|---|---|
## Diferenças reais entre os conceitos
## Materiais necessários
## Afirmações a confirmar
## Handoff para `$publicar-campanha-meta`
