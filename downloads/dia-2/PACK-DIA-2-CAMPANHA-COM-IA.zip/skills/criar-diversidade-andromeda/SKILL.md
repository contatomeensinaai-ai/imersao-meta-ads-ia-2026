---
name: criar-diversidade-andromeda
description: Use quando uma campanha Meta precisa de conceitos criativos realmente diferentes por dor, desejo, objeção, prova, processo, identidade, imagem e vídeo.
---

# Criar Diversidade Andrômeda

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a criação. Não crie prompt, tutorial, demonstração ou empresa fictícia.
- Não invente prova, depoimento, resultado, produto, dor ou benefício.
- Pergunte uma coisa por vez quando faltar material real do negócio.

## Sequência e arquivos

1. Leia `dossie-mercado/DOSSIÊ-DE-MERCADO-FINAL.md` e `campanha-ia/01-plano-campanha.md`.
2. Se algum arquivo estiver ausente, pare e indique a etapa anterior que falta.
3. Salve a matriz em `campanha-ia/02-matriz-criativos.md`.
4. Ao terminar, oriente o aluno a executar `$publicar-campanha-meta`, que deve ler o dossiê e os arquivos `01` e `02`.

## Fluxo

1. Leia a arquitetura e as evidências do público.
2. Liste as portas de entrada disponíveis: situação, dor, desejo, processo, objeção, prova e identidade local.
3. Escolha conceitos que expressem ângulos realmente diferentes.
4. Para cada conceito, defina gancho, mensagem, cena, formato, chamada para ação e prova necessária.
5. Compare o conjunto e elimine variações que mudam apenas palavras, cor ou recorte.
6. Preencha `templates/SAIDA.md`.

## Entrega

Matriz de Diversidade Criativa com conceitos de imagem e vídeo prontos para produção.

## Limites

- Não inventar prova, resultado, licença, avaliação ou depoimento.
- Não usar diversidade como desculpa para mensagens incoerentes.
- Não afirmar que um conceito será vencedor antes do teste.
- Não copiar criativo de concorrente.
