---
name: arquitetar-campanha
description: Use quando um Dossiê de Mercado confirmado precisa virar um plano de campanha Meta com objetivo, oferta, destino, região, investimento, capacidade e medição.
---

# Arquitetar Campanha

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a arquitetura. Não crie prompt, tutorial, demonstração ou campanha fictícia.
- Não invente negócio, oferta, público, investimento, destino ou objetivo.
- Faça uma pergunta aberta por vez quando faltar informação real.

## Sequência e arquivos

1. Leia `dossie-mercado/DOSSIÊ-DE-MERCADO-FINAL.md`. Esse é o contexto obrigatório do Dia 2.
2. Se o dossiê não existir, pare e oriente o aluno a concluir o Dia 1.
3. Crie a pasta `campanha-ia/` e salve o resultado em `campanha-ia/01-plano-campanha.md`.
4. Ao terminar, oriente o aluno a executar `$criar-diversidade-andromeda`, que deve ler o dossiê e o arquivo `01`.

## Fluxo

1. Leia o Dossiê de Mercado e sinalize lacunas ou contradições.
2. Confirme objetivo do negócio, serviço, região e caminho após o clique.
3. Pergunte quem atende os contatos e como acontece o acompanhamento.
4. Peça ao dono a faixa de investimento que ele aceita testar.
5. Defina objetivo de campanha, estrutura, conceito, destino e medição como proposta revisável.
6. Preencha `templates/SAIDA.md`.

## Entrega

Arquitetura de Campanha com decisões, justificativas, hipóteses, riscos e checklist de prontidão.

## Limites

- Não escolher orçamento pelo dono.
- Não prometer leads, vendas ou retorno.
- Não publicar ou alterar campanha.
- Não ignorar capacidade de atendimento e follow up.
