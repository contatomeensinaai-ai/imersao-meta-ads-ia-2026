# Arquitetura de Campanha
## Objetivo
## Oferta
## Região e público
## Caminho após o clique
## Atendimento
## Orçamento proposto pelo dono
## Estrutura
## Medição
## Riscos
## Hipóteses e a confirmar
## Checklist de prontidão
## Handoff para `$criar-diversidade-andromeda`
