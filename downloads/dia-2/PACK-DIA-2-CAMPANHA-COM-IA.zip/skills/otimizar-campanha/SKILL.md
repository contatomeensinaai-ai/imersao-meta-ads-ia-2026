---
name: otimizar-campanha
description: Use quando um diagnóstico de campanha precisa virar recomendações priorizadas de teste com sinais esperados, riscos, datas de revisão e aprovação.
---

# Otimizar Campanha

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute o plano de otimização. Não crie prompt, tutorial, demonstração ou resultados fictícios.
- Não invente métricas, causa, orçamento ou melhoria esperada.
- Faça uma pergunta aberta por vez quando faltar dado para decidir.

## Sequência e arquivos

1. Leia o Dossiê Final e todos os arquivos de `campanha-ia/01-plano-campanha.md` a `04-analise-campanha.md`.
2. Se a análise não existir ou não tiver dados suficientes, pare e indique a lacuna.
3. Salve o plano em `campanha-ia/05-plano-otimizacao.md`.
4. Entregue recomendações e gates. Não execute alterações sem nova aprovação explícita.

## Fluxo

1. Leia o diagnóstico e confirme se há dados suficientes para decidir.
2. Classifique cada elemento em manter, observar, testar, reduzir, pausar ou escalar.
3. Recomende uma mudança principal por teste sempre que possível.
4. Defina hipótese, ação, sinal esperado, risco, período e critério de revisão.
5. Mostre impactos de orçamento e dependências.
6. Entregue o plano sem executar alterações.

## Entrega

Plano de Otimização priorizado, com testes comparáveis e gates de aprovação.

## Limites

- Não movimentar orçamento, pausar ou editar campanha sem aprovação explícita.
- Não escalar somente porque uma métrica melhorou por pouco tempo.
- Não trocar muitas variáveis e chamar isso de teste.
- Não garantir resultado futuro.
