# Diagnóstico de Campanha
## Objetivo e período
## Entrega
## Interesse
## Cliques e destino
## Conversões
## Qualidade e atendimento
## Gargalos prováveis
## Hipóteses
## Dados ausentes
## Próxima pergunta
