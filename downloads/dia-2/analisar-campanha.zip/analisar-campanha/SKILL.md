---
name: analisar-campanha
description: Use when Meta campaign metrics, creative performance, landing behavior, lead quality, and follow-up data need a read-only diagnosis tied to the campaign objective.
---

# Analisar Campanha

## Fluxo

1. Confirme período, objetivo, orçamento, evento de conversão e mudanças recentes.
2. Leia dados de campanha, conjunto, anúncio e criativo sem alterar estado.
3. Conecte entrega, interesse, clique, conversão, qualidade do contato e atendimento.
4. Compare segmentos somente quando períodos e condições forem compatíveis.
5. Separe observação, interpretação e hipótese.
6. Preencha `templates/SAIDA.md`.

## Entrega

Diagnóstico de Campanha com fatos, gargalos prováveis, hipóteses e perguntas para a próxima decisão.

## Limites

- Não declarar causalidade a partir de correlação.
- Não analisar métrica isolada como resultado do negócio.
- Não editar campanha ou orçamento.
- Não esconder falta de volume ou rastreamento incompleto.
