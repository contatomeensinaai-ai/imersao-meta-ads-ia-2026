---
name: analisar-campanha
description: Use quando métricas de campanha Meta, criativos, página, qualidade dos contatos e atendimento precisam de um diagnóstico somente leitura ligado ao objetivo.
---

# Analisar Campanha

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a análise. Não crie prompt, tutorial, demonstração, métricas ou campanha fictícia.
- Se não houver dados reais suficientes, pare e peça o período ou a fonte necessária.
- Faça uma pergunta aberta por vez e não transforme pouco volume em conclusão.

## Sequência e arquivos

1. Leia o Dossiê Final e todos os arquivos existentes de `campanha-ia/01-plano-campanha.md` a `03-publicacao-campanha.md`.
2. Leia métricas reais da plataforma ou dados fornecidos pelo aluno sem alterar a campanha.
3. Salve o diagnóstico em `campanha-ia/04-analise-campanha.md`.
4. Ao terminar, oriente o aluno a executar `$otimizar-campanha`, que deve ler todo o contexto e a análise.

## Fluxo

1. Confirme período, objetivo, orçamento, evento de conversão e mudanças recentes.
2. Leia dados de campanha, conjunto, anúncio e criativo sem alterar estado.
3. Conecte entrega, interesse, clique, conversão, qualidade do contato e atendimento.
4. Compare segmentos somente quando períodos e condições forem compatíveis.
5. Separe observação, interpretação e hipótese.
6. Preencha `templates/SAIDA.md`.

## Entrega

Diagnóstico de Campanha com fatos, gargalos prováveis, hipóteses e perguntas para a próxima decisão.

## Limites

- Não declarar causalidade a partir de correlação.
- Não analisar métrica isolada como resultado do negócio.
- Não editar campanha ou orçamento.
- Não esconder falta de volume ou rastreamento incompleto.
