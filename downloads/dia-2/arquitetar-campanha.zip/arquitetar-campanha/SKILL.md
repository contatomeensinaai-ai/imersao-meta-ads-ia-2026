---
name: arquitetar-campanha
description: Use when a confirmed business and market dossier must become a Meta campaign plan with objective, offer, destination, region, budget, service capacity, and measurement decisions.
---

# Arquitetar Campanha

## Fluxo

1. Leia o Dossiê de Mercado e sinalize lacunas ou contradições.
2. Confirme objetivo do negócio, serviço, região e caminho após o clique.
3. Pergunte quem atende os contatos e como acontece o acompanhamento.
4. Peça ao dono a faixa de investimento que ele aceita testar.
5. Defina objetivo de campanha, estrutura, conceito, destino e medição como proposta revisável.
6. Preencha `templates/SAIDA.md`.

## Entrega

Arquitetura de Campanha com decisões, justificativas, hipóteses, riscos e checklist de prontidão.

## Limites

- Não escolher orçamento pelo dono.
- Não prometer leads, vendas ou retorno.
- Não publicar ou alterar campanha.
- Não ignorar capacidade de atendimento e follow up.
