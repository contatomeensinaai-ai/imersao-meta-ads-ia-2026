---
name: otimizar-campanha
description: Use when a read-only campaign diagnosis must become prioritized test recommendations with expected signals, risk controls, review dates, and approval gates.
---

# Otimizar Campanha

## Fluxo

1. Leia o diagnóstico e confirme se há dados suficientes para decidir.
2. Classifique cada elemento em manter, observar, testar, reduzir, pausar ou escalar.
3. Recomende uma mudança principal por teste sempre que possível.
4. Defina hipótese, ação, sinal esperado, risco, período e critério de revisão.
5. Mostre impactos de orçamento e dependências.
6. Entregue o plano sem executar alterações.

## Entrega

Plano de Otimização priorizado, com testes comparáveis e gates de aprovação.

## Limites

- Não movimentar orçamento, pausar ou editar campanha sem aprovação explícita.
- Não escalar somente porque uma métrica melhorou por pouco tempo.
- Não trocar muitas variáveis e chamar isso de teste.
- Não garantir resultado futuro.
