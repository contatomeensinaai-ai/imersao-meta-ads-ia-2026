---
name: criar-diversidade-andromeda
description: Use when a Meta campaign needs genuinely different creative concepts across pains, desires, objections, proof, process, identity, images, and videos instead of superficial variations.
---

# Criar Diversidade Andrômeda

## Fluxo

1. Leia a arquitetura e as evidências do público.
2. Liste as portas de entrada disponíveis: situação, dor, desejo, processo, objeção, prova e identidade local.
3. Escolha conceitos que expressem ângulos realmente diferentes.
4. Para cada conceito, defina gancho, mensagem, cena, formato, chamada para ação e prova necessária.
5. Compare o conjunto e elimine variações que mudam apenas palavras, cor ou recorte.
6. Preencha `templates/SAIDA.md`.

## Entrega

Matriz de Diversidade Criativa com conceitos de imagem e vídeo prontos para produção.

## Limites

- Não inventar prova, resultado, licença, avaliação ou depoimento.
- Não usar diversidade como desculpa para mensagens incoerentes.
- Não afirmar que um conceito será vencedor antes do teste.
- Não copiar criativo de concorrente.
