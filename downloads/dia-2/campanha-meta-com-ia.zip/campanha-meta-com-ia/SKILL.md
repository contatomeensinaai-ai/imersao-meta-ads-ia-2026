---
name: campanha-meta-com-ia
description: Use when a business owner or marketing professional wants guided help diagnosing a Meta Ads account, choosing a campaign, producing disruptive Andromeda-ready creatives, and preparing or reviewing execution in one conversation.
---

# Campanha Meta com IA

## Resultado

Conduza o participante, em português do Brasil, da leitura da conta até uma campanha e seus criativos prontos para aprovação. Mantenha todo o trabalho na mesma conversa. Ensine a decisão enquanto executa; não entregue um prompt para a pessoa executar depois.

## Regras centrais

- Faça uma pergunta por vez.
- Use informações reais. Não crie empresa, campanha, métrica, prova, avaliação ou resultado fictício.
- Comece pela conexão e por uma leitura segura da conta. Leia [conexao-e-diagnostico.md](references/conexao-e-diagnostico.md).
- Depois pergunte pelo Dossiê de Mercado e escolha o modo completo, parcial ou sem Dossiê. Leia [fluxo-guiado.md](references/fluxo-guiado.md).
- Explique as opções antes de recomendar uma campanha. Leia [decisao-de-campanha.md](references/decisao-de-campanha.md).
- Para conceitos, Reels e imagens, aplique [andromeda-disruptiva.md](references/andromeda-disruptiva.md).
- Mantenha um bloco `Estado da Campanha` atualizado na conversa. A pessoa deve poder responder apenas `continuar`.
- Antes de criar, editar, publicar, ativar, pausar ou mudar orçamento, mostre a ação exata e peça aprovação explícita. Aprovação para criar não autoriza ativar.

## Conclusão

Entregue na própria conversa:

1. diagnóstico da conta;
2. recomendação explicada;
3. estrutura da campanha;
4. matriz criativa;
5. roteiros de Reels;
6. imagens geradas ou, quando a plataforma não permitir, prompts prontos para produção;
7. checklist de rastreamento e atendimento;
8. ação seguinte que depende de aprovação.

Não encerre alegando que a pessoa precisa abrir outro chat ou chamar outra habilidade.
