# Decisão de campanha

## Pergunta em linguagem simples

Pergunte o que a pessoa quer alcançar e apresente opções compreensíveis:

- fazer mais pessoas da região conhecerem a empresa;
- levar pessoas para o site;
- receber formulários;
- iniciar conversas;
- gerar vendas.

Explique cada opção antes de pedir a escolha. Depois recomende uma direção com evidências da conta, do Dossiê ou do Briefing Essencial.

## Critérios

### Reconhecimento

Use quando o objetivo imediato for presença e lembrança. Para a prática inicial, pode propor cinco dias de teste e uma publicação existente, mas:

- verifique moeda e orçamento mínimo da conta;
- trate US$ 5 por dia ou R$ 10 por dia como exemplo ajustável, nunca como valor universal;
- peça confirmação do investimento;
- avalie a força do post antes de usá-lo;
- se o post for genérico, proponha um novo criativo.

### Site

Diferencie clique de conversão. Para otimizar conversões no site, verifique página, Pixel, evento e qualidade do rastreamento. Não prometa instalar rastreamento apenas por navegar; implemente somente com acesso autorizado ao site e aprovação.

### Formulário

Verifique oferta, perguntas, privacidade, qualificação, velocidade de resposta e capacidade de atendimento.

### Conversas

Verifique canal, disponibilidade, tempo de resposta e se o público já tem contexto suficiente para iniciar uma conversa.

### Vendas

Verifique checkout, eventos, catálogo quando aplicável, Pixel ou dataset e medição. A API de Conversões pode melhorar a medição, mas não a apresente como solução mágica ou requisito idêntico para todos os casos.

## Recomendação

Apresente:

1. campanha recomendada;
2. motivos;
3. requisitos disponíveis;
4. requisitos ausentes;
5. risco principal;
6. alternativa segura.

Confirme se a pessoa entendeu antes de estruturar campanha, conjunto e anúncio.
