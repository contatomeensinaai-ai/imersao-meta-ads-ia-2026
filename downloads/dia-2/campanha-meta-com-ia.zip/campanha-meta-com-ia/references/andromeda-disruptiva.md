# Diversidade Andrômeda disruptiva

## Objetivo

Crie diversidade de conceitos e sinais criativos, não pequenas variações da mesma peça. Use o Dossiê, o plano da campanha, ativos reais e restrições da marca.

## Coleta

Pergunte uma coisa por vez:

- Quais fotos e vídeos reais estão disponíveis?
- A pessoa aceita aparecer?
- Existem reviews ou depoimentos com autorização?
- Há identidade visual e referências aprovadas?
- Quais formatos serão produzidos agora?

## Territórios criativos

Escolha territórios compatíveis com o negócio, como:

- verdade incômoda;
- metáfora visual inesperada;
- inimigo invisível;
- custo de não agir;
- transformação desejada;
- bastidor que o cliente não vê;
- história ou prova autorizada;
- conteúdo educativo que muda a percepção.

Desconto não pode ser a ideia central. Evite “qualidade e confiança”, banco de imagem corporativo, profissional de braços cruzados, robôs e hologramas genéricos.

## Teste de ruptura

Para cada conceito, responda:

1. Um concorrente poderia trocar apenas o logo e usar a mesma campanha?
2. A imagem comunica antes de a pessoa ler?
3. O gancho interrompe atenção sem enganar?
4. A ideia nasce de uma dor, desejo, review ou oportunidade real?
5. Ela é estruturalmente diferente das outras?

Reprove e refaça qualquer conceito genérico ou que mude apenas cor, palavra, enquadramento ou promoção.

## Entrega de Reels

Entregue para cada vídeo:

- objetivo e motivação;
- gancho dos primeiros segundos;
- texto falado completo;
- cenas e enquadramentos;
- texto na tela;
- duração;
- chamada para ação;
- orientação de gravação e edição.

## Entrega de imagens

Quando houver ferramenta de geração de imagens, gere as peças na própria conversa usando ativos e referências autorizados. Confira texto, proporção e aderência à marca. Produza os formatos necessários para feed, Stories ou Reels.

Quando a plataforma não puder gerar imagens, declare a limitação e entregue prompts de produção completos, incluindo composição, metáfora, ambiente, iluminação, proporção e espaço para copy.

## Matriz final

Para cada conceito, registre gancho, visual, copy, título, chamada para ação, formato, público ou motivação, evidência usada e diferença em relação às demais peças. Não afirme antecipadamente qual será vencedor.
