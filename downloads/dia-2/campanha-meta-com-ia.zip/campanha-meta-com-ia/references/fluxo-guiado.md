# Fluxo guiado na mesma conversa

## Nível de experiência

Após escolher a conta, pergunte:

> Qual é seu nível de experiência com anúncios: iniciante, já anunciei algumas vezes ou profissional/agência?

- Iniciante: explique termos em uma frase e confirme compreensão antes de decisões importantes.
- Intermediário: explique apenas decisões e riscos relevantes.
- Profissional ou agência: seja conciso, exponha evidências, hipóteses e controles.

## Dossiê

Pergunte:

> Você já tem o Dossiê de Mercado criado no Dia 1?

### Dossiê completo

Peça o arquivo, leia-o e use suas evidências. Ainda assim, confirme diretamente com a pessoa a cidade ou região desta campanha, o serviço, o objetivo, o destino, o orçamento, a duração, os materiais atuais e a capacidade de atendimento. O Dossiê pode estar desatualizado ou cobrir mais de uma região.

### Dossiê parcial

Peça o material existente, aproveite o conteúdo confirmado e complete apenas as lacunas.

### Sem Dossiê

Diga que a pessoa pode continuar e faça uma pergunta por vez para formar um Briefing Essencial:

1. negócio e serviço principal;
2. cidade ou região atendida;
3. cliente que normalmente compra;
4. problema resolvido;
5. diferencial verdadeiro;
6. ação desejada após o anúncio;
7. destino disponível: site, formulário, conversa ou checkout;
8. materiais reais disponíveis;
9. capacidade e velocidade de atendimento;
10. investimento que aceita testar.

Não invente pesquisa de mercado ausente. Marque hipóteses e sugira completar o Dossiê depois.

## Estado da Campanha

Ao final de cada fase, atualize um resumo curto:

```markdown
## Estado da Campanha
- Conta escolhida:
- Experiência:
- Dossiê: completo, parcial ou briefing essencial
- Serviço e região:
- Objetivo recomendado:
- Destino:
- Rastreamento:
- Investimento aprovado:
- Criativos:
- Publicação: não autorizada, criação autorizada ou ativação autorizada
- Próximo passo:
```

Antes de qualquer escrita na Meta, todos os campos necessários devem estar preenchidos e o próximo passo deve exibir conta, região, objetivo, orçamento, duração e status pausado ou ativo. Peça aprovação desse resumo; uma resposta anterior genérica não substitui essa aprovação.

Continue na mesma conversa. Não exija cópia para outro chat, arquivo intermediário ou chamada manual de outra habilidade.
