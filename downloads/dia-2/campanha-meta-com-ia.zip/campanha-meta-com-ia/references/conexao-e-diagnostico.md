# Conexão e diagnóstico

## Primeiro contato

Pergunte primeiro:

> Sua conta de anúncios da Meta já está conectada nesta ferramenta?

Se a resposta for incerta, tente localizar as ferramentas oficiais do Facebook Ads e fazer uma consulta somente leitura das contas disponíveis. Nunca teste a conexão criando ou alterando uma campanha.

## Quando estiver conectado

1. Liste todas as contas visíveis com nome e situação. Se a resposta trouxer `next_cursor`, continue paginando até não haver outra página.
2. Peça para a pessoa escolher a conta correta.
3. Confirme moeda e forma de pagamento. Trate separadamente `account_status`, `is_queryable` e `is_ads_mcp_enabled`; uma conta ativa não significa automaticamente que ela pode ser consultada ou usada pelo MCP.
4. Consulte campanhas anteriores e identifique se a conta já anunciou.
5. Se houver dúvida sobre uma conta, pergunte; não escolha pelo usuário.

Mesmo que exista apenas uma conta aparentemente adequada, diga seu nome e ID e peça confirmação. Não crie um objeto de teste para validar conexão; valide a conexão com leitura.

## Quando não estiver conectado

Ofereça duas opções sem bloquear a aula:

1. configurar a conexão agora;
2. continuar pelo modo assistido, usando Dossiê, respostas, prints ou relatório.

Para ChatGPT e Codex, a conexão pode ser criada no ChatGPT web, na mesma conta e workspace: Configurações, Plugins, modo desenvolvedor, criar plugin personalizado e usar `https://mcp.facebook.com/ads`. Depois de autenticar, o plugin compatível pode ser selecionado no Codex. A disponibilidade depende do plano, workspace, permissões e superfície.

Para Claude: Configurações, Conectores, Adicionar conector personalizado, nome `Meta Ads` e URL `https://mcp.facebook.com/ads`.

## Histórico

Se já houver campanhas, pergunte uma coisa por vez:

- O que a pessoa tentou alcançar?
- Qual campanha ela considera mais importante analisar?
- Os contatos ou vendas tinham qualidade?
- Como era o atendimento depois do contato?

Use dados reais disponíveis na conta. Não conclua desempenho por uma métrica isolada.

Se não houver campanhas, explique que um teste inicial de reconhecimento pode ser uma estratégia para começar a distribuir presença local. Não apresente “aquecimento obrigatório” como regra oficial da Meta.

Antes de recomendar esse teste, confirme cidade ou região, serviço, público, orçamento, duração, material que será usado e capacidade de atendimento.
