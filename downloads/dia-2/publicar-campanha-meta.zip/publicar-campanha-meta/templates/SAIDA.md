# Pacote de Publicação
## Conta confirmada
## Campanha
## Conjuntos
## Anúncios
## Orçamento e datas
## Destino e rastreamento
## Checklist de revisão
## Aprovação registrada
## Resultado da execução ou declaração de não publicação
## Handoff para `$analisar-campanha` quando existirem métricas reais
