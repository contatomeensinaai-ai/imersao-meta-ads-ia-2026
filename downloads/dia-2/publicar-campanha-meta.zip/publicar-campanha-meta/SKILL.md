---
name: publicar-campanha-meta
description: Use quando uma campanha Meta revisada precisa ser preparada para publicação por uma conexão autorizada ou convertida em um checklist manual completo.
---

# Publicar Campanha Meta

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a preparação. Não crie prompt, tutorial, demonstração ou configuração fictícia.
- Não invente conta, identificador, orçamento, evento, URL ou resultado.
- Faça perguntas com dados reais e peça aprovação imediatamente antes de qualquer escrita externa.

## Sequência e arquivos

1. Leia `dossie-mercado/DOSSIÊ-DE-MERCADO-FINAL.md`, `campanha-ia/01-plano-campanha.md` e `02-matriz-criativos.md`.
2. Se algum arquivo estiver ausente, pare e indique a skill anterior que falta.
3. Salve o checklist e o registro do resultado em `campanha-ia/03-publicacao-campanha.md`.
4. Se nada for publicado, registre isso claramente no arquivo.
5. Quando existirem métricas reais, oriente o aluno a executar `$analisar-campanha`, que deve ler todo o contexto acumulado.

## Escolha do modo

Use modo conectado somente quando a ferramenta oficial estiver autenticada, a conta correta estiver confirmada e houver permissão de escrita. Caso contrário, use modo checklist.

## Modo conectado

1. Faça leitura de empresas, contas e campanhas disponíveis.
2. Confirme identificador, nome, moeda, fuso e status da conta.
3. Monte a proposta sem criar nada.
4. Mostre campanha, conjuntos, anúncios, orçamento, datas, destino e rastreamento.
5. Peça aprovação explícita imediatamente antes da escrita.
6. Após aprovação, execute somente o escopo aprovado e verifique o resultado.

## Modo checklist

Gere todos os campos e passos manuais usando `templates/SAIDA.md`. Declare claramente que nada foi publicado.

## Entrega

Campanha verificada na plataforma ou pacote manual completo, sempre com registro do que aconteceu.

## Limites

- Nunca presumir a conta correta.
- Nunca publicar, pausar, editar ou movimentar orçamento sem aprovação imediata.
- Não armazenar senha, token ou código.
- Parar diante de restrição, cobrança desconhecida ou acesso suspeito.
