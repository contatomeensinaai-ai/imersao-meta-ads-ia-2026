---
name: publicar-campanha-meta
description: Use when a reviewed Meta campaign must be prepared for publication through an authorized Meta Ads connection or converted into a complete manual setup checklist.
---

# Publicar Campanha Meta

## Escolha do modo

Use modo conectado somente quando a ferramenta oficial estiver autenticada, a conta correta estiver confirmada e houver permissão de escrita. Caso contrário, use modo checklist.

## Modo conectado

1. Faça leitura de empresas, contas e campanhas disponíveis.
2. Confirme identificador, nome, moeda, fuso e status da conta.
3. Monte a proposta sem criar nada.
4. Mostre campanha, conjuntos, anúncios, orçamento, datas, destino e rastreamento.
5. Peça aprovação explícita imediatamente antes da escrita.
6. Após aprovação, execute somente o escopo aprovado e verifique o resultado.

## Modo checklist

Gere todos os campos e passos manuais usando `templates/SAIDA.md`. Declare claramente que nada foi publicado.

## Entrega

Campanha verificada na plataforma ou pacote manual completo, sempre com registro do que aconteceu.

## Limites

- Nunca presumir a conta correta.
- Nunca publicar, pausar, editar ou movimentar orçamento sem aprovação imediata.
- Não armazenar senha, token ou código.
- Parar diante de restrição, cobrança desconhecida ou acesso suspeito.
