# Diagnóstico do funil

## Ordem da análise

1. Conte oportunidades por etapa.
2. Some valores por etapa apenas quando a moeda e os valores forem confiáveis.
3. Calcule passagem entre etapas somente quando a ordem e o período forem comparáveis.
4. Identifique oportunidades paradas usando a regra confirmada com a pessoa.
5. Calcule tempo médio ou mediano na etapa quando houver datas suficientes.
6. Compare origens apenas quando a origem estiver preenchida em volume razoável.
7. Liste lacunas antes de concluir causas.

Correlação não prova causa. Uma queda entre etapas pode refletir atendimento, qualificação, oferta, preço, sazonalidade ou dado incompleto. Apresente hipóteses como hipóteses.

## Diagnóstico em linguagem simples

Entregue:

- **Visão geral:** tamanho e valor conhecido do funil.
- **Maior gargalo:** onde há acúmulo, demora ou queda sustentada pelos dados.
- **Oportunidades paradas:** quantidade por etapa e urgência.
- **Follow-up:** lacunas de atividade ou registro.
- **Qualidade dos dados:** o que pode e não pode ser concluído.
- **Plano de sete dias:** de três a sete ações específicas, priorizadas e executáveis.

## JSON agregado para o painel

Crie um arquivo JSON sem dados pessoais:

```json
{
  "empresa": "Nome da empresa",
  "periodo": "1 a 31 de agosto de 2026",
  "moeda": "USD",
  "etapas": [
    {
      "nome": "Novo lead",
      "quantidade": 24,
      "valor": 12000,
      "paradas": 8,
      "tempo_medio_dias": 5
    }
  ],
  "gargalos": ["Descrição sustentada pelos dados"],
  "acoes": ["Ação prioritária para os próximos sete dias"],
  "lacunas": ["Campo ausente ou limitação da análise"]
}
```

Use `null` quando um indicador não puder ser calculado. Não use zero para representar informação ausente.

## Painel visual

Quando houver execução local:

```bash
python3 scripts/gerar_painel.py funil-agregado.json RAIO-X-DO-FUNIL.html
```

O painel precisa mostrar etapas, quantidade, valor conhecido, oportunidades paradas, tempo médio, taxas de passagem calculáveis, gargalos, plano de sete dias e lacunas. O arquivo deve funcionar offline e oferecer **Salvar em PDF**.
