# Entrada e privacidade

## Escolha da fonte

Pergunte onde os dados estão e siga o caminho correspondente:

- **CRM conectado:** localize a conexão disponível e faça apenas consultas de leitura. Confirme a conta e o pipeline antes de consultar oportunidades.
- **CSV:** leia cabeçalhos, quantidade de linhas, formatos de data e campos vazios antes de mapear colunas.
- **Excel ou XLSX:** inspecione as abas e pergunte qual representa o funil. Se a plataforma não conseguir ler Excel, peça uma exportação CSV.
- **Dados colados:** peça cabeçalhos e linhas em formato de tabela. Não exija formatação perfeita.
- **Anotações ou nenhum controle:** faça uma entrevista curta para mapear as etapas e indique quais campos começar a registrar. Não invente números.

## Campos úteis

Priorize, quando existirem:

- identificador anônimo da oportunidade;
- etapa atual;
- data de criação;
- data da última atividade;
- data de entrada na etapa;
- valor estimado;
- origem do lead;
- responsável;
- resultado, ganho ou perdido;
- motivo de perda.

Nome, telefone, email, endereço e conteúdo de mensagens não são necessários para a análise agregada. Oriente a pessoa a remover essas colunas quando possível.

## Confirmação do mapa

Antes de calcular, apresente:

1. colunas reconhecidas;
2. etapas encontradas e sua ordem provável;
3. regra proposta para considerar uma oportunidade parada;
4. período analisado;
5. campos ausentes.

Peça confirmação. Se houver duas interpretações possíveis, explique em linguagem simples e pergunte qual representa a operação real.

## Segurança

- Não copie dados para serviços públicos.
- Não exponha dados pessoais no HTML.
- Não conecte outra conta por semelhança de nome.
- Não escreva no CRM durante o diagnóstico.
- Não prometa privacidade absoluta de uma plataforma de terceiros; informe que o painel gerado pelo script é um arquivo local sem recursos externos.
