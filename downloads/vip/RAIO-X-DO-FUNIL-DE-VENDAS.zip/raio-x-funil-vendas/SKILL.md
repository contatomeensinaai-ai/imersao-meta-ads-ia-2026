---
name: raio-x-funil-vendas
description: Use when a business owner needs to understand sales pipeline health, bottlenecks, stalled opportunities, follow-up gaps, or CRM and spreadsheet funnel data through a visual diagnosis.
---

# Raio X do Funil de Vendas

## Resultado

Ajude a pessoa a entender o funil de vendas em português do Brasil. Aceite dados de CRM, CSV, Excel ou dados colados. Entregue um diagnóstico explicado, um plano de sete dias e um painel visual privado em HTML que possa ser salvo como PDF.

## Fluxo

1. Pergunte uma coisa por vez. Comece com: **“Onde seus contatos e oportunidades estão hoje: CRM, planilha, anotações ou ainda não estão organizados?”**
2. Leia [entrada-e-privacidade.md](references/entrada-e-privacidade.md) e escolha o modo de entrada adequado.
3. Mostre as etapas encontradas, explique qualquer dúvida e peça confirmação antes de analisar. Não suponha que nomes de colunas ou estágios significam a mesma coisa em empresas diferentes.
4. Leia [diagnostico-do-funil.md](references/diagnostico-do-funil.md), calcule somente o que os dados sustentam e marque lacunas claramente.
5. Apresente primeiro uma síntese simples: o que está funcionando, o maior gargalo e a ação mais importante.
6. Monte o JSON agregado descrito na referência e, quando puder executar arquivos, use `scripts/gerar_painel.py` para gerar `RAIO-X-DO-FUNIL.html`.
7. Entregue também o diagnóstico no chat. Explique que o painel abre no navegador e o botão **Salvar em PDF** usa a impressão do navegador.

## Limites

- Não invente quantidade, valor, conversão, origem, prazo ou resultado.
- Não peça senha, token ou credencial. Conexões com CRM são somente leitura durante o diagnóstico.
- Minimize dados pessoais. Nomes, telefones, emails e mensagens individuais não são necessários para o painel agregado.
- Não envie follow-up, não altere etapas, não edite o CRM e não atribua oportunidades sem aprovação explícita separada.
- Quando não houver dados suficientes, entregue o mapa do processo atual e a lista exata dos campos que a pessoa deve começar a registrar. Não simule um painel como se fossem dados reais.
- Não publique o painel na internet. Ele deve permanecer local ou ser entregue diretamente à pessoa.

## Alternativa sem execução de arquivos

Se a plataforma não conseguir executar o script, gere um artefato visual equivalente na própria ferramenta e forneça uma versão para download quando houver suporte. Se isso também não for possível, entregue tabelas visuais no chat, o diagnóstico e o plano de sete dias sem afirmar que criou um arquivo.
