#!/usr/bin/env python3
import html
import json
import sys
from pathlib import Path


def text(value, fallback="Não informado"):
    if value is None or value == "":
        return fallback
    return html.escape(str(value))


def number(value):
    if value is None:
        return "Não calculado"
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return text(value)


def money(value, currency):
    if value is None:
        return "Não calculado"
    try:
        formatted = f"{float(value):,.2f}"
    except (TypeError, ValueError):
        return text(value)
    return f"{text(currency, '')} {formatted}".strip()


def list_items(items, empty):
    values = items if isinstance(items, list) and items else [empty]
    return "".join(f"<li>{text(item)}</li>" for item in values)


def build(data):
    stages = data.get("etapas") if isinstance(data.get("etapas"), list) else []
    max_count = max([stage.get("quantidade") or 0 for stage in stages] or [1])
    currency = data.get("moeda") or ""
    total_count = sum(stage.get("quantidade") or 0 for stage in stages)
    known_values = [stage.get("valor") for stage in stages if stage.get("valor") is not None]
    total_value = sum(known_values) if known_values else None
    total_stalled = sum(stage.get("paradas") or 0 for stage in stages)
    stage_cards = []
    previous = None
    for index, stage in enumerate(stages):
        count = stage.get("quantidade")
        width = 8 if not count else max(8, round((count / max_count) * 100))
        conversion = None
        if previous not in (None, 0) and count is not None:
            conversion = round((count / previous) * 100, 1)
        conversion_text = "Entrada do funil" if index == 0 else (f"{conversion}% da etapa anterior" if conversion is not None else "Não calculado")
        stage_cards.append(f"""
        <article class="stage">
          <div class="stage-head"><div><span>Etapa {index + 1}</span><h3>{text(stage.get('nome'))}</h3></div><strong>{number(count)}</strong></div>
          <div class="bar" aria-label="Proporção visual desta etapa"><i style="width:{width}%"></i></div>
          <dl><div><dt>Valor conhecido</dt><dd>{money(stage.get('valor'), currency)}</dd></div><div><dt>Paradas</dt><dd>{number(stage.get('paradas'))}</dd></div><div><dt>Tempo médio</dt><dd>{number(stage.get('tempo_medio_dias'))} dias</dd></div><div><dt>Passagem</dt><dd>{conversion_text}</dd></div></dl>
        </article>""")
        previous = count
    if not stage_cards:
        stage_cards.append('<article class="stage"><h3>Dados insuficientes</h3><p>As etapas ainda não foram informadas.</p></article>')

    return f"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Raio X do Funil de Vendas</title>
<style>
:root{{--bg:#08090d;--surface:#151720;--line:#2a2d39;--text:#f7f7fb;--muted:#a9adba;--gold:#f5b642;--red:#ff6b6b;--green:#43d19e}}*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(circle at 90% 0,#2b2110 0,transparent 35rem),var(--bg);color:var(--text);font:16px/1.5 Inter,system-ui,sans-serif}}header,main,footer{{width:min(1120px,calc(100% - 2rem));margin:auto}}header{{padding:2rem 0 1rem;display:flex;justify-content:space-between;gap:1rem;align-items:center}}button{{min-height:48px;padding:.8rem 1rem;border:0;border-radius:.7rem;background:var(--gold);color:#1b1202;font-weight:800;cursor:pointer}}button:focus-visible{{outline:3px solid white;outline-offset:3px}}.hero{{padding:3rem 0 2rem}}.eyebrow{{color:var(--gold);font-size:.78rem;font-weight:850;letter-spacing:.12em;text-transform:uppercase}}h1{{font-size:clamp(2.4rem,8vw,5.8rem);line-height:.95;letter-spacing:-.05em;margin:.5rem 0 1rem}}h2{{font-size:clamp(1.5rem,4vw,2.5rem)}}.muted{{color:var(--muted)}}.metrics,.stages,.diagnosis{{display:grid;gap:1rem}}.metrics{{grid-template-columns:repeat(2,minmax(0,1fr))}}.metric,.stage,.panel{{border:1px solid var(--line);border-radius:1rem;background:linear-gradient(145deg,#191b25,#101119);padding:1.1rem}}.metric strong{{display:block;font-size:clamp(1.5rem,5vw,2.6rem)}}.stage-head{{display:flex;justify-content:space-between;gap:1rem;align-items:start}}.stage-head span{{color:var(--muted);font-size:.8rem}}.stage h3{{margin:.15rem 0}}.stage-head>strong{{font-size:2rem;color:var(--gold)}}.bar{{height:.7rem;background:#282b35;border-radius:999px;overflow:hidden;margin:1rem 0}}.bar i{{display:block;height:100%;background:linear-gradient(90deg,var(--gold),#ffe29a);border-radius:inherit}}dl{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.8rem;margin:0}}dt{{color:var(--muted);font-size:.78rem}}dd{{margin:0;font-weight:750}}.diagnosis{{margin:2rem 0}}ul{{padding-left:1.2rem}}footer{{padding:2rem 0 4rem;color:var(--muted)}}@media(min-width:760px){{.metrics{{grid-template-columns:repeat(3,minmax(0,1fr))}}.stages{{grid-template-columns:repeat(2,minmax(0,1fr))}}.diagnosis{{grid-template-columns:repeat(3,minmax(0,1fr))}}}}@media print{{body{{background:white;color:#111}}button{{display:none}}.metric,.stage,.panel{{background:white;border-color:#ccc;break-inside:avoid}}.muted,dt{{color:#555}}}}
</style></head><body>
<header><div><strong>ME ENSINA AI</strong><div class="eyebrow">Diagnóstico privado</div></div><button type="button" onclick="window.print()">Salvar em PDF</button></header>
<main><section class="hero"><div class="eyebrow">Raio X do Funil de Vendas</div><h1>{text(data.get('empresa'))}</h1><p class="muted">Período analisado: {text(data.get('periodo'))}</p></section>
<section aria-labelledby="resumo"><h2 id="resumo">Visão geral</h2><div class="metrics"><article class="metric"><span class="muted">Oportunidades nas etapas</span><strong>{number(total_count)}</strong></article><article class="metric"><span class="muted">Valor conhecido</span><strong>{money(total_value, currency)}</strong></article><article class="metric"><span class="muted">Oportunidades paradas</span><strong>{number(total_stalled)}</strong></article></div></section>
<section aria-labelledby="funil"><h2 id="funil">Etapas do funil</h2><div class="stages">{''.join(stage_cards)}</div></section>
<section class="diagnosis" aria-label="Diagnóstico e plano"><article class="panel"><div class="eyebrow">Gargalos</div><ul>{list_items(data.get('gargalos'), 'Nenhum gargalo pôde ser confirmado com os dados disponíveis.')}</ul></article><article class="panel"><div class="eyebrow">Plano de sete dias</div><ul>{list_items(data.get('acoes'), 'Defina a primeira ação após completar os dados.')}</ul></article><article class="panel"><div class="eyebrow">Lacunas</div><ul>{list_items(data.get('lacunas'), 'Nenhuma lacuna relevante foi registrada.')}</ul></article></section></main>
<footer>Arquivo local gerado pelo Raio X do Funil de Vendas. Nenhum dado é enviado por esta página.</footer></body></html>"""


def main():
    if len(sys.argv) != 3:
        raise SystemExit("Uso: gerar_painel.py funil-agregado.json RAIO-X-DO-FUNIL.html")
    source, target = map(Path, sys.argv[1:])
    data = json.loads(source.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SystemExit("O JSON precisa conter um objeto na raiz.")
    target.write_text(build(data), encoding="utf-8")
    print(f"Painel gerado: {target}")


if __name__ == "__main__":
    main()
