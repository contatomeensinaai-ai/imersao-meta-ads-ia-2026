---
name: analisar-chatgpt-ads
description: Use quando entrega, cliques, investimento, custos, conversões, criativos e página de uma campanha ChatGPT Ads precisam de diagnóstico somente leitura.
---

# Analisar ChatGPT Ads

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a análise. Não crie prompt, tutorial, demonstração, métricas ou campanha fictícia.
- Se não houver dados reais suficientes, pare e peça a informação necessária.
- Faça uma pergunta aberta por vez e não confunda pouco volume com conclusão.

## Sequência e arquivos

1. Leia `dossie-mercado/DOSSIÊ-DE-MERCADO-FINAL.md`, `campanha-chatgpt-ads/01-plano-chatgpt-ads.md` e os dados reais da campanha.
2. Se o plano ou as métricas não existirem, pare e indique a lacuna.
3. Salve o diagnóstico em `campanha-chatgpt-ads/02-analise-chatgpt-ads.md`.
4. Encerre com próximos testes e pontos a confirmar, sem executar alterações externas.

## Fluxo

1. Confirme objetivo, período, orçamento, mudanças e medição.
2. Leia campanha, grupos e anúncios sem alterar estado.
3. Compare entrega, cliques, custos, conversões e páginas dentro de condições compatíveis.
4. Avalie cobertura criativa e coerência entre contexto, anúncio e destino.
5. Separe fatos, interpretações, hipóteses e dados ausentes.
6. Use `templates/SAIDA.md`.

## Entrega

Diagnóstico de ChatGPT Ads com gargalos prováveis, oportunidades de teste e próxima decisão.

## Limites

- Não interpretar pouco volume como conclusão definitiva.
- Não confundir clique barato com resultado de negócio.
- Não editar campanha ou orçamento.
- Não garantir desempenho futuro.
