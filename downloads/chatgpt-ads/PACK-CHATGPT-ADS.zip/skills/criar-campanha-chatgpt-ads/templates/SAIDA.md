# Pacote de Campanha ChatGPT Ads
## Conta e prontidão
## Objetivo
## Orçamento e datas
## Localizações
## Grupos e pistas de contexto
## Anúncios
## Páginas e UTMs
## Medição
## Checklist de revisão
## Aprovações necessárias
## Fontes oficiais e data
## Handoff para `$analisar-chatgpt-ads` quando existirem métricas reais
