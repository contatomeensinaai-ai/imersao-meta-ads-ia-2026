---
name: criar-campanha-chatgpt-ads
description: Use when a business needs a review-ready ChatGPT Ads campaign with objective, budget, locations, context-based ad groups, diverse ads, landing pages, and measurement decisions.
---

# Criar Campanha ChatGPT Ads

## Fluxo

1. Verifique a documentação oficial atual porque o Ads Manager está em beta.
2. Confirme objetivo, oferta, público, localizações, orçamento e medição.
3. Estruture campanha, grupos por situação ou intenção e anúncios específicos.
4. Crie diversidade de mensagem, benefício, imagem e página de destino.
5. Adicione UTMs e checklist de conversão.
6. Mostre o pacote completo para revisão.

## Entrega

Pacote de Campanha ChatGPT Ads preenchido em `templates/SAIDA.md`.

## Limites

- Não presumir disponibilidade, mínimo de verba ou campo da interface.
- Não inventar contexto, prova ou benefício.
- Não publicar nem movimentar orçamento sem aprovação explícita.
- Não tratar beta como produto estável.
