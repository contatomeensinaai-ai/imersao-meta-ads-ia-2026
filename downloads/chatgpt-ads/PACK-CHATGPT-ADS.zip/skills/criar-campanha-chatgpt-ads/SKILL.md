---
name: criar-campanha-chatgpt-ads
description: Use quando um negócio precisa preparar uma campanha de ChatGPT Ads com objetivo, investimento, regiões, grupos por contexto, anúncios, páginas e medição.
---

# Criar Campanha ChatGPT Ads

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a arquitetura. Não crie prompt, tutorial, demonstração ou campanha fictícia.
- Não invente disponibilidade, conta, campo da interface, público, investimento, prova ou resultado.
- Faça uma pergunta aberta por vez quando faltar informação real.

## Sequência e arquivos

1. Leia `dossie-mercado/DOSSIÊ-DE-MERCADO-FINAL.md` e os arquivos relevantes de `campanha-ia/`.
2. Se o Dossiê Final não existir, pare e oriente o aluno a concluir o Dia 1.
3. Crie a pasta `campanha-chatgpt-ads/` e salve o resultado em `campanha-chatgpt-ads/01-plano-chatgpt-ads.md`.
4. Quando existirem métricas reais, oriente o aluno a executar `$analisar-chatgpt-ads`, que deve ler todo o contexto acumulado.

## Fluxo

1. Verifique a documentação oficial atual porque o Ads Manager está em beta.
2. Confirme objetivo, oferta, público, localizações, orçamento e medição.
3. Estruture campanha, grupos por situação ou intenção e anúncios específicos.
4. Crie diversidade de mensagem, benefício, imagem e página de destino.
5. Adicione UTMs e checklist de conversão.
6. Mostre o pacote completo para revisão.

## Entrega

Pacote de Campanha ChatGPT Ads preenchido em `templates/SAIDA.md`.

## Limites

- Não presumir disponibilidade, mínimo de verba ou campo da interface.
- Não inventar contexto, prova ou benefício.
- Não publicar nem movimentar orçamento sem aprovação explícita.
- Não tratar beta como produto estável.
