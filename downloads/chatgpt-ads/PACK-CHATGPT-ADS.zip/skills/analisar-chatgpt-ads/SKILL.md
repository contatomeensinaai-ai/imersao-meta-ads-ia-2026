---
name: analisar-chatgpt-ads
description: Use when ChatGPT Ads campaign delivery, clicks, spend, costs, conversions, creative coverage, and landing performance need a read-only diagnosis against the chosen objective.
---

# Analisar ChatGPT Ads

## Fluxo

1. Confirme objetivo, período, orçamento, mudanças e medição.
2. Leia campanha, grupos e anúncios sem alterar estado.
3. Compare entrega, cliques, custos, conversões e páginas dentro de condições compatíveis.
4. Avalie cobertura criativa e coerência entre contexto, anúncio e destino.
5. Separe fatos, interpretações, hipóteses e dados ausentes.
6. Use `templates/SAIDA.md`.

## Entrega

Diagnóstico de ChatGPT Ads com gargalos prováveis, oportunidades de teste e próxima decisão.

## Limites

- Não interpretar pouco volume como conclusão definitiva.
- Não confundir clique barato com resultado de negócio.
- Não editar campanha ou orçamento.
- Não garantir desempenho futuro.
