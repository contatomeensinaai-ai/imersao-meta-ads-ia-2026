# Diagnóstico de ChatGPT Ads
## Objetivo e período
## Entrega e gasto
## Cliques e custos
## Conversões
## Cobertura criativa
## Contexto, anúncio e página
## Gargalos prováveis
## Hipóteses de teste
## Dados ausentes
## Próxima decisão
