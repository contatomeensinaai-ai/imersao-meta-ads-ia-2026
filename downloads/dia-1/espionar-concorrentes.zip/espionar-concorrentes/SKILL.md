---
name: espionar-concorrentes
description: Use quando um negócio local precisa comparar posicionamento, ofertas, provas, chamadas para ação, sites e experiência pública dos concorrentes.
---

# Espionar Concorrentes

## Visão geral

Compare concorrentes para localizar padrões e espaços de diferenciação, sem copiar identidade, texto ou oferta.

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a pesquisa. Não crie prompt, tutorial, demonstração ou exemplo para o aluno copiar.
- Não invente empresa, concorrente, cidade ou resultado para completar a atividade.
- Se faltarem dados reais, faça uma pergunta aberta por vez e espere a resposta antes de continuar.
- Comece confirmando negócio, serviço e região. Depois pergunte se o aluno já conhece algum concorrente.

## Sequência e arquivos

1. Antes de começar, leia `dossie-mercado/00-contexto-negocio.md` e `dossie-mercado/01-mercado-local.md`.
2. Se algum arquivo não existir, pare e oriente o aluno a concluir `$analisar-mercado-local` na mesma tarefa.
3. Use o contexto acumulado e pergunte somente as lacunas reais.
4. Salve o resultado em `dossie-mercado/02-concorrentes.md`.
5. Ao terminar, oriente o aluno a executar `$minerar-reviews`. A próxima skill deve ler os arquivos `00`, `01` e `02`.

## Fluxo

1. Confirme serviço, região e concorrentes conhecidos. Se não houver nomes, pesquise opções públicas relevantes.
2. Defina critérios comuns: posicionamento, serviço destacado, oferta, prova, chamada para ação, canais e experiência de contato.
3. Consulte sites, perfis e páginas públicas atuais.
4. Registre exatamente o que foi observado e marque interpretações como hipótese.
5. Compare no máximo opções relevantes o suficiente para revelar padrões, sem fingir cobertura total do mercado.
6. Produza a matriz em `templates/SAIDA.md`.

## Entrega

Matriz de Concorrentes com padrões, lacunas e oportunidades de diferenciação comprovável.

## Limites

- Não copiar anúncios, textos, imagens ou marca.
- Não declarar faturamento, desempenho ou qualidade sem evidência.
- Não usar dados privados ou contornar acesso.
- Não difamar concorrentes.
