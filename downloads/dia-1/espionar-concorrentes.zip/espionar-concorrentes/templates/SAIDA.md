# Matriz de Concorrentes

## Escopo
| Concorrente | Posicionamento | Oferta | Provas | Chamada para ação | Canais |
|---|---|---|---|---|---|

## Padrões do mercado
## Lacunas observadas
## Oportunidades de diferenciação
## Hipóteses
## A confirmar
## Fontes e data da consulta
## Handoff para `$minerar-reviews`
