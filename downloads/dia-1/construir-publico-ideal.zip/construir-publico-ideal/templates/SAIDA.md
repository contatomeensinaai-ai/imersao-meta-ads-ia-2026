# Público Prioritário

## Situação atual
## Necessidade principal
## Objeções
## Critérios de decisão
## Momento de procura
## Linguagem observada
## Evidências
## Hipóteses
## A confirmar
## Handoff para `$mapear-oportunidades`
