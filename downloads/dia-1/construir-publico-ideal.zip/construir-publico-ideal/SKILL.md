---
name: construir-publico-ideal
description: Use quando um negócio precisa definir um público prioritário com base em situações, necessidades, objeções, critérios de decisão e momentos de compra reais.
---

# Construir Público Ideal

## Visão geral

Construa um público prioritário a partir do negócio, mercado, concorrentes e reviews. Comece pela situação vivida, não por uma personagem fictícia.

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a construção do público. Não crie prompt, tutorial ou exemplo genérico.
- Não invente persona, idade, renda, profissão, família, hábito ou dor.
- Se faltarem pesquisas ou dados reais, faça uma pergunta aberta por vez e marque as lacunas como `A CONFIRMAR`.
- Não avance para uma persona fictícia apenas para preencher o modelo.

## Sequência e arquivos

1. Antes de começar, leia todos os arquivos de `dossie-mercado/00-contexto-negocio.md` até `03-reviews.md`.
2. Se uma etapa anterior estiver ausente, pare e indique exatamente qual skill precisa ser concluída.
3. Construa o público usando o contexto acumulado, não somente o resultado de reviews.
4. Salve o resultado em `dossie-mercado/04-publico-prioritario.md`.
5. Ao terminar, oriente o aluno a executar `$mapear-oportunidades`. A próxima skill deve ler os arquivos `00` a `04`.

## Fluxo

1. Leia as entregas disponíveis e liste fatos, evidências, hipóteses e lacunas.
2. Confirme serviço, região e capacidade do negócio.
3. Agrupe situações de necessidade, urgência, objeções e critérios de decisão.
4. Priorize o grupo cuja necessidade combina com a capacidade e a oferta reais.
5. Registre linguagem observada e momentos que podem despertar procura.
6. Produza a saída usando `templates/SAIDA.md`.

## Entrega

Perfil de Público Prioritário com situação, necessidade, objeções, critérios de decisão, momento de procura, linguagem e evidências.

## Limites

- Não inventar idade, renda, profissão, família ou hábitos.
- Não confundir público de campanha com segmentação detalhada da plataforma.
- Não usar atributos sensíveis para explorar vulnerabilidades.
- Não tratar hipótese como certeza.
