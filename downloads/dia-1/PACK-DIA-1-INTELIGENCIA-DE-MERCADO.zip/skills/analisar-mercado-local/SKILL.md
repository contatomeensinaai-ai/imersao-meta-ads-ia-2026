---
name: analisar-mercado-local
description: Use when a local business needs evidence about a service area, visible demand, competition, seasonality, and market limitations before choosing an advertising direction.
---

# Analisar Mercado Local

## Visão geral

Construa um mapa verificável da região antes de recomendar campanha. Pesquise apenas depois de confirmar serviço e área atendida.

## Fluxo

1. Pergunte uma coisa por vez: serviço prioritário, cidade ou raio, capacidade, faixa de valor e objetivo.
2. Resuma o contexto e peça confirmação.
3. Pesquise fontes públicas atuais sobre a região, procura aparente, sazonalidade e concorrência visível.
4. Diferencie evidência de inferência. Não transforme volume de resultados ou presença digital em tamanho exato de mercado.
5. Registre fonte, link e data.
6. Produza a entrega usando `templates/SAIDA.md`.

## Entrega

Mapa de Mercado Local com contexto, sinais observados, oportunidades, riscos, limitações e perguntas a confirmar.

## Limites

- Não invente demanda, renda, preço médio, CAC ou tamanho de mercado.
- Não trate uma fonte isolada como verdade da região.
- Não recomende orçamento como regra universal.
- Não acesse conta, dado privado ou informação sensível.
