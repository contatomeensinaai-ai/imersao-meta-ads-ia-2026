---
name: gerar-dossie-de-mercado
description: Use when separate business, market, competitor, review, audience, and opportunity findings need to become one consistent source document for campaign planning.
---

# Gerar Dossiê de Mercado

## Visão geral

Consolide as entregas sem apagar lacunas. O dossiê é a fonte de contexto do Dia 2.

## Fluxo

1. Localize as entregas disponíveis e informe o que estiver ausente.
2. Extraia fatos, evidências, hipóteses e informações a confirmar.
3. Compare arquivos e destaque contradições antes de escolher uma interpretação.
4. Organize a direção mais defensável para serviço, região, público, oportunidade e mensagem.
5. Preserve fontes e datas.
6. Preencha `templates/SAIDA.md` e encerre com prioridades para o Dia 2.

## Entrega

Dossiê de Mercado consolidado, verificável e pronto para alimentar criação de oferta, criativos e campanha.

## Limites

- Não completar campos ausentes com suposição.
- Não esconder divergências.
- Não afirmar tamanho de mercado, preço, demanda ou retorno sem fonte adequada.
- Não autorizar campanha ou orçamento.
