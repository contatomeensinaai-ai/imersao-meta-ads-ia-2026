---
name: construir-publico-ideal
description: Use when a business needs an evidence-based priority audience defined by situations, needs, objections, decision criteria, and buying moments rather than invented demographics.
---

# Construir Público Ideal

## Visão geral

Construa um público prioritário a partir do negócio, mercado, concorrentes e reviews. Comece pela situação vivida, não por uma personagem fictícia.

## Fluxo

1. Leia as entregas disponíveis e liste fatos, evidências, hipóteses e lacunas.
2. Confirme serviço, região e capacidade do negócio.
3. Agrupe situações de necessidade, urgência, objeções e critérios de decisão.
4. Priorize o grupo cuja necessidade combina com a capacidade e a oferta reais.
5. Registre linguagem observada e momentos que podem despertar procura.
6. Produza a saída usando `templates/SAIDA.md`.

## Entrega

Perfil de Público Prioritário com situação, necessidade, objeções, critérios de decisão, momento de procura, linguagem e evidências.

## Limites

- Não inventar idade, renda, profissão, família ou hábitos.
- Não confundir público de campanha com segmentação detalhada da plataforma.
- Não usar atributos sensíveis para explorar vulnerabilidades.
- Não tratar hipótese como certeza.
