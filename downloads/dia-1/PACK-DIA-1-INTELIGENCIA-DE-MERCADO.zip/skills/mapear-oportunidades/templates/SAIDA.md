# Mapa de Oportunidades

| Oportunidade | Evidência | Aderência | Capacidade | Facilidade de teste | Prioridade |
|---|---|---|---|---|---|

## Três prioridades
## Trade-offs
## Primeiras ações
## Riscos
## A confirmar
