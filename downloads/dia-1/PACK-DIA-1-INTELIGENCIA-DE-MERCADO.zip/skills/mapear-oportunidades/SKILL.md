---
name: mapear-oportunidades
description: Use when market, competitor, review, and audience findings need to be crossed with business capacity to prioritize realistic advertising and positioning opportunities.
---

# Mapear Oportunidades

## Visão geral

Transforme pesquisa em escolhas. Uma oportunidade só é prioridade quando existe evidência, aderência ao negócio e capacidade de execução.

## Fluxo

1. Leia os mapas de mercado, concorrentes, reviews e público.
2. Remova duplicações e aponte contradições.
3. Gere oportunidades em quatro áreas: mensagem, oferta, atendimento e presença local.
4. Avalie cada oportunidade por evidência, aderência, capacidade e facilidade de teste.
5. Recomende até três prioridades, explicando os trade-offs.
6. Use `templates/SAIDA.md`.

## Entrega

Mapa de Oportunidades priorizado, com evidência, razão, risco, primeira ação e informação a confirmar.

## Limites

- Não transformar oportunidade em promessa de resultado.
- Não recomendar desconto como padrão.
- Não priorizar algo que exceda a capacidade da empresa.
- Não esconder contradições entre as fontes.
