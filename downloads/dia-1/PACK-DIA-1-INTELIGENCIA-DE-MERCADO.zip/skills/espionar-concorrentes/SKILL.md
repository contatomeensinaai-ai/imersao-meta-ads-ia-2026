---
name: espionar-concorrentes
description: Use when a local business needs a source-backed comparison of public competitor positioning, offers, proof, calls to action, websites, and visible customer experience.
---

# Espionar Concorrentes

## Visão geral

Compare concorrentes para localizar padrões e espaços de diferenciação, sem copiar identidade, texto ou oferta.

## Fluxo

1. Confirme serviço, região e concorrentes conhecidos. Se não houver nomes, pesquise opções públicas relevantes.
2. Defina critérios comuns: posicionamento, serviço destacado, oferta, prova, chamada para ação, canais e experiência de contato.
3. Consulte sites, perfis e páginas públicas atuais.
4. Registre exatamente o que foi observado e marque interpretações como hipótese.
5. Compare no máximo opções relevantes o suficiente para revelar padrões, sem fingir cobertura total do mercado.
6. Produza a matriz em `templates/SAIDA.md`.

## Entrega

Matriz de Concorrentes com padrões, lacunas e oportunidades de diferenciação comprovável.

## Limites

- Não copiar anúncios, textos, imagens ou marca.
- Não declarar faturamento, desempenho ou qualidade sem evidência.
- Não usar dados privados ou contornar acesso.
- Não difamar concorrentes.
