---
name: minerar-reviews
description: Use quando avaliações públicas precisam ser analisadas para encontrar dores, desejos, objeções, sinais de confiança, linguagem e oportunidades de atendimento.
---

# Minerar Reviews

## Visão geral

Use avaliações públicas para entender experiências recorrentes. Frequência, contexto e diversidade de fontes importam mais que uma frase chamativa.

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a análise. Não crie prompt, tutorial, demonstração ou reviews fictícios.
- Não invente empresa, cliente, avaliação, recorrência ou conclusão.
- Se faltarem dados reais, faça uma pergunta aberta por vez. Comece confirmando negócio, serviço e região.
- Se ainda não houver concorrentes ou fontes, informe o que precisa ser pesquisado em vez de simular resultados.

## Sequência e arquivos

1. Antes de começar, leia `dossie-mercado/00-contexto-negocio.md`, `01-mercado-local.md` e `02-concorrentes.md`.
2. Se os arquivos anteriores não existirem, pare e indique a etapa que ainda precisa ser concluída.
3. Use mercado e concorrentes para localizar e analisar reviews reais.
4. Salve o resultado em `dossie-mercado/03-reviews.md`.
5. Ao terminar, oriente o aluno a executar `$construir-publico-ideal`. A próxima skill deve ler os arquivos `00` a `03`.

## Fluxo

1. Leia em `02-concorrentes.md` quais concorrentes foram confirmados ou pesquisados e quais fontes públicas pertencem a cada um.
2. Confirme se o aluno deseja acrescentar ou retirar algum concorrente antes da coleta.
3. Colete uma amostra identificável de reviews públicos dos concorrentes selecionados, separando positivos, negativos e intermediários por concorrente e fonte.
4. Classifique temas: qualidade, comunicação, prazo, confiança, preço, limpeza, processo e pós-atendimento.
5. Identifique reclamações recorrentes, elogios recorrentes, objeções, critérios de decisão e linguagem usada pelos clientes.
6. Conte recorrências sem inventar representatividade estatística.
7. Preserve frases curtas apenas quando necessário e dentro dos limites de citação; prefira paráfrases.
8. Produza o mapa em `templates/SAIDA.md`.

## Entrega

Mapa de Reviews com dores, desejos, objeções, sinais de confiança, linguagem e oportunidades de atendimento ou comunicação.

## Limites

- Uma avaliação isolada não define o mercado.
- Não identificar cliente comum nem expor dado pessoal.
- Não fabricar depoimento ou atribuir intenção não observada.
- Não recomendar promessa que o negócio não possa comprovar.
