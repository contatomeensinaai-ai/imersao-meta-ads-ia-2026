---
name: minerar-reviews
description: Use when public customer reviews need to be analyzed for recurring pains, desires, objections, trust signals, language patterns, and service opportunities.
---

# Minerar Reviews

## Visão geral

Use avaliações públicas para entender experiências recorrentes. Frequência, contexto e diversidade de fontes importam mais que uma frase chamativa.

## Fluxo

1. Confirme serviço, região e fontes permitidas.
2. Colete amostra identificável de reviews positivos, negativos e intermediários.
3. Classifique temas: qualidade, comunicação, prazo, confiança, preço, limpeza, processo e pós-atendimento.
4. Conte recorrências sem inventar representatividade estatística.
5. Preserve frases curtas apenas quando necessário e dentro dos limites de citação; prefira paráfrases.
6. Produza o mapa em `templates/SAIDA.md`.

## Entrega

Mapa de Reviews com dores, desejos, objeções, sinais de confiança, linguagem e oportunidades de atendimento ou comunicação.

## Limites

- Uma avaliação isolada não define o mercado.
- Não identificar cliente comum nem expor dado pessoal.
- Não fabricar depoimento ou atribuir intenção não observada.
- Não recomendar promessa que o negócio não possa comprovar.
