# Mapa de Reviews

## Amostra e fontes
## Temas recorrentes
## Dores
## Desejos
## Objeções
## Sinais de confiança
## Linguagem do público
## Oportunidades
## Limitações e a confirmar
## Handoff para `$construir-publico-ideal`
