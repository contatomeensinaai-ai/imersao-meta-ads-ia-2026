---
name: mapear-oportunidades
description: Use quando descobertas sobre mercado, concorrentes, reviews e público precisam ser cruzadas com a capacidade do negócio para priorizar oportunidades reais.
---

# Mapear Oportunidades

## Visão geral

Transforme pesquisa em escolhas. Uma oportunidade só é prioridade quando existe evidência, aderência ao negócio e capacidade de execução.

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute o cruzamento das pesquisas. Não crie prompt, tutorial ou exemplo genérico.
- Não invente pesquisas anteriores, capacidade, oportunidade ou resultado.
- Se alguma entrega estiver ausente, informe a lacuna e faça uma pergunta aberta por vez.
- Só priorize oportunidades sustentadas pelos dados reais fornecidos ou pesquisados.

## Sequência e arquivos

1. Antes de começar, leia todos os arquivos de `dossie-mercado/00-contexto-negocio.md` até `04-publico-prioritario.md` ou o bloco `CONTEXTO ACUMULADO DO CADERNO DE MERCADO` com as Etapas 1 a 4.
2. Aceite o contexto acumulado do caderno como alternativa completa aos arquivos. Se uma etapa estiver ausente, indique qual resultado deve ser preenchido no caderno.
3. Cruze o contexto completo. Não use apenas o último arquivo.
4. Salve o resultado em `dossie-mercado/05-oportunidades.md`.
5. Ao terminar, oriente o aluno a colar o resultado na Etapa 5 do Caderno de Mercado, clicar em `Copiar contexto até aqui` e executar `$gerar-dossie-de-mercado` no próximo chat.

## Fluxo

1. Leia o contexto do negócio e os mapas de mercado, concorrentes, reviews e público.
2. Remova duplicações e aponte contradições.
3. Cruze seis elementos: regiões desejadas, sinais do mercado, lacunas dos concorrentes, reclamações e elogios dos reviews, necessidades do público prioritário e capacidade real do negócio.
4. Gere oportunidades em quatro áreas: mensagem, oferta, atendimento e presença local. Cada oportunidade deve indicar quais evidências cruzadas a sustentam.
5. Avalie cada oportunidade por evidência, aderência ao público, capacidade do negócio, diferenciação e facilidade de teste.
6. Recomende até três prioridades, explicando os trade-offs e por que foram escolhidas sobre as demais.
7. Use `templates/SAIDA.md`.

## Entrega

Mapa de Oportunidades priorizado, com evidência, razão, risco, primeira ação e informação a confirmar.

## Limites

- Não transformar oportunidade em promessa de resultado.
- Não recomendar desconto como padrão.
- Não priorizar algo que exceda a capacidade da empresa.
- Não esconder contradições entre as fontes.
