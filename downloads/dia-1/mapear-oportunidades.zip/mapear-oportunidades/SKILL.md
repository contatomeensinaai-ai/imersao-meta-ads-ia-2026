---
name: mapear-oportunidades
description: Use quando descobertas sobre mercado, concorrentes, reviews e público precisam ser cruzadas com a capacidade do negócio para priorizar oportunidades reais.
---

# Mapear Oportunidades

## Visão geral

Transforme pesquisa em escolhas. Uma oportunidade só é prioridade quando existe evidência, aderência ao negócio e capacidade de execução.

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute o cruzamento das pesquisas. Não crie prompt, tutorial ou exemplo genérico.
- Não invente pesquisas anteriores, capacidade, oportunidade ou resultado.
- Se alguma entrega estiver ausente, informe a lacuna e faça uma pergunta aberta por vez.
- Só priorize oportunidades sustentadas pelos dados reais fornecidos ou pesquisados.

## Sequência e arquivos

1. Antes de começar, leia todos os arquivos de `dossie-mercado/00-contexto-negocio.md` até `04-publico-prioritario.md`.
2. Se uma etapa estiver ausente, pare e indique a skill que falta.
3. Cruze o contexto completo. Não use apenas o último arquivo.
4. Salve o resultado em `dossie-mercado/05-oportunidades.md`.
5. Ao terminar, oriente o aluno a executar `$gerar-dossie-de-mercado`. A próxima skill deve ler os arquivos `00` a `05`.

## Fluxo

1. Leia os mapas de mercado, concorrentes, reviews e público.
2. Remova duplicações e aponte contradições.
3. Gere oportunidades em quatro áreas: mensagem, oferta, atendimento e presença local.
4. Avalie cada oportunidade por evidência, aderência, capacidade e facilidade de teste.
5. Recomende até três prioridades, explicando os trade-offs.
6. Use `templates/SAIDA.md`.

## Entrega

Mapa de Oportunidades priorizado, com evidência, razão, risco, primeira ação e informação a confirmar.

## Limites

- Não transformar oportunidade em promessa de resultado.
- Não recomendar desconto como padrão.
- Não priorizar algo que exceda a capacidade da empresa.
- Não esconder contradições entre as fontes.
