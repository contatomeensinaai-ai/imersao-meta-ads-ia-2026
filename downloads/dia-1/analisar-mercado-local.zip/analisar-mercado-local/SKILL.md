---
name: analisar-mercado-local
description: Use quando um negócio local precisa entender região, demanda visível, concorrência, sazonalidade e limitações de mercado antes de definir a direção dos anúncios.
---

# Analisar Mercado Local

## Visão geral

Construa um mapa verificável da região antes de recomendar campanha. Pesquise apenas depois de confirmar serviço e área atendida.

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Execute a análise. Não crie prompt, tutorial, demonstração ou exemplo para o aluno copiar.
- Não invente empresa, serviço, cidade, público ou números para “montar um exemplo realista”.
- Se faltarem dados reais, pare e faça uma pergunta aberta por vez. Comece perguntando qual é o negócio, o serviço prioritário e a região atendida.
- Não anuncie que vai “usar a skill exatamente como foi criada”. Comece diretamente pela entrevista.

## Sequência e arquivos

1. Trabalhe na mesma tarefa e no mesmo projeto durante todo o Dia 1.
2. Crie a pasta `dossie-mercado/`.
3. Salve as respostas confirmadas da entrevista em `dossie-mercado/00-contexto-negocio.md`.
4. Salve o resultado desta skill em `dossie-mercado/01-mercado-local.md`.
5. Ao terminar, oriente o aluno a executar `$espionar-concorrentes`. Essa próxima skill deve ler os arquivos `00` e `01`, sem pedir que o aluno copie e cole o conteúdo.

## Fluxo

1. Pergunte uma coisa por vez: serviço prioritário, cidade ou raio, capacidade, faixa de valor e objetivo.
2. Resuma o contexto e peça confirmação.
3. Pesquise fontes públicas atuais sobre a região, procura aparente, sazonalidade e concorrência visível.
4. Diferencie evidência de inferência. Não transforme volume de resultados ou presença digital em tamanho exato de mercado.
5. Registre fonte, link e data.
6. Produza a entrega usando `templates/SAIDA.md`.

## Entrega

Mapa de Mercado Local com contexto, sinais observados, oportunidades, riscos, limitações e perguntas a confirmar.

## Limites

- Não invente demanda, renda, preço médio, CAC ou tamanho de mercado.
- Não trate uma fonte isolada como verdade da região.
- Não recomende orçamento como regra universal.
- Não acesse conta, dado privado ou informação sensível.
