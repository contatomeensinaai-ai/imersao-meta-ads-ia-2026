# Dossiê de Mercado

## Resumo executivo
## Negócio e capacidade
## Mercado local
## Concorrentes
## Reviews e linguagem
## Público prioritário
## Oportunidades
## Direção para campanha
## Fatos
## Evidências e fontes
## Hipóteses
## Contradições
## A confirmar
## Prioridades para o Dia 2
## Arquivo de entrada para as skills do Dia 2
