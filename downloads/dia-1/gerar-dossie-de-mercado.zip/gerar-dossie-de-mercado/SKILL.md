---
name: gerar-dossie-de-mercado
description: Use quando pesquisas separadas de negócio, mercado, concorrentes, reviews, público e oportunidades precisam formar um documento único para planejar campanhas.
---

# Gerar Dossiê de Mercado

## Visão geral

Consolide as entregas sem apagar lacunas. O dossiê é a fonte de contexto do Dia 2.

## Idioma e modo de execução

- Responda sempre em português do Brasil, salvo pedido explícito em outro idioma.
- Gere o dossiê com dados reais. Não crie prompt, tutorial, demonstração ou exemplo preenchido.
- Não invente entregas ausentes, empresa, mercado, concorrente, público ou oportunidade.
- Se faltarem arquivos ou respostas, liste as lacunas e faça uma pergunta aberta por vez.
- Preserve `A CONFIRMAR` até que o aluno forneça ou aprove a informação real.

## Sequência e arquivos

1. Antes de começar, leia todos os arquivos de `dossie-mercado/00-contexto-negocio.md` até `05-oportunidades.md` ou o bloco `CONTEXTO ACUMULADO DO CADERNO DE MERCADO` com as Etapas 1 a 5.
2. Aceite o contexto acumulado do caderno como alternativa completa aos arquivos. Se uma etapa estiver ausente, indique qual resultado deve ser preenchido. Não complete a lacuna com exemplo.
3. Consolide o contexto acumulado, preservando fontes, contradições e itens a confirmar.
4. Salve a entrega final em `dossie-mercado/DOSSIÊ-DE-MERCADO-FINAL.md`.
5. Oriente o aluno a colar o dossiê na Etapa 6 do Caderno de Mercado e baixar uma cópia. Informe que esse dossiê será a entrada das skills do Dia 2.

## Fluxo

1. Localize as entregas disponíveis e informe o que estiver ausente.
2. Extraia fatos, evidências, hipóteses e informações a confirmar.
3. Compare arquivos e destaque contradições antes de escolher uma interpretação.
4. Organize a direção mais defensável para serviço, região, público, oportunidade e mensagem.
5. Preserve fontes e datas.
6. Preencha `templates/SAIDA.md` e encerre com prioridades para o Dia 2.

## Entrega

Dossiê de Mercado consolidado, verificável e pronto para alimentar criação de oferta, criativos e campanha.

## Limites

- Não completar campos ausentes com suposição.
- Não esconder divergências.
- Não afirmar tamanho de mercado, preço, demanda ou retorno sem fonte adequada.
- Não autorizar campanha ou orçamento.
